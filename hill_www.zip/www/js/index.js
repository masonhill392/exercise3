var app = new Framework7({
    // App root element
    el: '#app',
    // ... other parameters
  });
var mainView = app.views.create('.view-main')